package com.example.germaneduardomora.librorecetas;

/**
 * Created by German on 05/01/2016.
 */
public class Item {

    private Integer idR;
    private String nombreR;
    private String pathR;

    public Item() {
    }

    public Integer getIdR() {
        return idR;
    }

    public String getNombreR() {
        return nombreR;
    }

    public void setIdR(Integer idR) {
        this.idR = idR;
    }

    public void setNombreR(String nombreR) {
        this.nombreR = nombreR;
    }

    public void setPathR(String pathR) {
        this.pathR = pathR;
    }

    public String getPathR() {
        return pathR;


    }
}
